public class MinesweeperModel {

    public int[][] grid = new int[15][15];
    public int[][] gameGrid = new int[15][15];
    public double probability= 3.5;
    public double chance = (int)(Math.random()*(10))+1;
    public int count = 0;
    public final int open = 1;
    public static final int closed =0;
    public int flags =20;
    public static final int flagged=-4;
    public static final int questioned = -5;
    public boolean gameOver = false;
    public MinesweeperModel(){

        for (int r = 0; r <=14; r++){
            for(int c = 0; c <= 14; c++){
                chance = (int)(Math.random()*(10))+1;
                
                if (probability >= chance && r > 1){
                    grid[r][c]=-1;
                    gameGrid[r][c] = -1;
                    count++;
                }else { 
                    grid[r][c] =0;
                }
            }
        }            
    }

    public int surroundingBombs(int r, int c){
        int surroundCount =0;
        if(r == 0  && c == 0 ){
           if(grid[r][c+1] == -1){
               surroundCount++;
           }
           if(grid[r+1][c+1] == -1){
           }   surroundCount++;

           if(grid[r+1][c] == -1){
           }   surroundCount++;

        }
        else if(r==0 && c==14){
            if(grid[r][c-1] == -1){
                surroundCount++;
            }
            if(grid[r+1][c] ==-1){
                surroundCount++;
            }
            if(grid[r+1][c-1] == -1){
                surroundCount++;
            }
        }
        else if(r==14 && c==0){
            if(grid[r-1][c] == -1){
                surroundCount++;
            }
            if(grid[r][c+1] ==-1){
                surroundCount++;
            }
            if(grid[r-1][c=1]==-1){
                surroundCount++;
            }
        }
        else if(r==14 && c==14){
            if(grid[r][c-1] == -1){
                surroundCount++;
            }
            if(grid[r-1][c-1] == -1){
            }   surroundCount++;
            if(grid[r-1][c] == -1){
            }   surroundCount++;
         }
        else if(r==0 && (0<c && c < 14)){
            if(grid[r+1][c] == -1){
                surroundCount++;
            }
            if(grid[r][c-1]== -1){
                surroundCount++;
            }
            if(grid[r][c+1]== -1){
                surroundCount++;
            }
            if(grid[r+1][c+1]== -1){
                surroundCount++;
            }
            if(grid[r+1][c-1]==-1){
                surroundCount++;
            }

        }
        else if(r==14 && (0<c && c < 14)){
            if(grid[r-1][c] == -1){
                surroundCount++;
            }
            if(grid[r][c-1]== -1){
                surroundCount++;
            }
            if(grid[r][c+1]== -1){
                surroundCount++;
            }
            if(grid[r-1][c+1]== -1){
                surroundCount++;
            }
            if(grid[r-1][c-1]==-1){
                surroundCount++;
            }
        }
        else if((0<r && r < 14 && c==0)){
            if(grid[r+1][c]== -1){
                surroundCount++;
            }
            if(grid[r][c+1]== -1){
                surroundCount++;
            }
            if(grid[r-1][c]== -1){
                surroundCount++;
            }
            if(grid[r+1][c+1]== -1){
                surroundCount++;
            }
            if(grid[r-1][c+1]== -1){
                surroundCount++;
            }
        }
        else if((0<r && r < 14 && c==14)){
            if(grid[r+1][c]== -1){
                surroundCount++;
            }
            if(grid[r][c-1]== -1){
                surroundCount++;
            }
            if(grid[r-1][c]== -1){
                surroundCount++;
            }
            if(grid[r+1][c-1]== -1){
                surroundCount++;
            }
            if(grid[r-1][c-1]== -1){
                surroundCount++;
            }
        }
        else{
            if(grid[r+1][c]== -1){
                surroundCount++;
            }
            if(grid[r][c-1]== -1){
                surroundCount++;
            }
            if(grid[r][c+1]== -1){
                surroundCount++;
            }
            if(grid[r-1][c]== -1){
                surroundCount++;
            }
            if(grid[r+1][c-1]== -1){
                surroundCount++;
            }
            if(grid[r-1][c-1]== -1){
                surroundCount++;
            }
            if(grid[r-1][c+1]== -1){
                surroundCount++;
            }
            if(grid[r+1][c+1]==-1){
                surroundCount++;
            }
        }

         return surroundCount;
    }
    public void reveal(int r, int c ){
        if(grid[r][c] !=open){
            if(grid[r][c] != -1){
                gameGrid[r][c] = surroundingBombs(r, c);
                System.out.println(r + "," + c + ", " + surroundingBombs(r,c));
                grid[r][c] = open;
            } else{ 
                gameOver= true;

            }

        }
    }
    public void setState(int r, int c){
        int state = gameGrid[r][c];

        if(state == 0){
            if(gameGrid[r][c]== -1){
            count--;
            }
            if(count== 0 && flags ==0){
                gameOver= true;
            }
            if(flags>0){
                state = flagged;
                flags--;
            }
            else{
                state = questioned;
            }
        }
        else if(state== flagged){
            state = questioned;

            if(flags >= 0){
                flags++;
            }
        }
        else if(state == questioned){
            state =0;
        }
gameGrid[r][c]=state;
    }
    public int getState(int r, int c){
        return gameGrid[r][c];
    }
    public boolean checkMine (int r, int c){
        if(grid[r][c]== -1){
            System.out.println(r + " " + c);
        return true;
        }
        else{ 
            return false;
        }
    }

    public static void main(String[]aStrings){

        MinesweeperModel model = new MinesweeperModel();

    }
}
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MinesweeperButtons extends JButton implements ActionListener{
    public MinesweeperPanel panel;
    public MinesweeperFrame frame;

    public MinesweeperButtons(MinesweeperFrame frame, int r, int c){
        super();
        this.addMouseListener(new MouseAdapter(){

            public void mouseClicked(MouseEvent e){
                System.out.println("click");
                if (frame.model.gameOver == false){
                    if(e.getButton()== 1 && frame.model.getState(r, c) != 1){
                        if(frame.model.getState(r, c)!= frame.model.flagged){
                            if(frame.model.checkMine(r, c)){
                                frame.model.gameOver =true;
                                System.out.println("Mine hit");
                            }
                            else{
                                System.out.println("reveal");
                                frame.model.reveal(r, c);
                                frame.panel.updateFrame(r, c);
                            }
                        }
                    }
                    if(e.getButton()==3 &&frame.model.getState(r, c)!=-1){
                        frame.model.setState(r, c);
                        frame.panel.updateFrame(r, c);
                        frame.repaint();
                    }

                }
                //frame.repaint();
            }
        });
    }
    
    public void actionPerformed(ActionEvent e)
    {

    }
    public void setImage(ImageIcon icon, int w, int h){
        Image img = icon.getImage();
        Image newImage = img.getScaledInstance(w,h,Image.SCALE_REPLICATE);
        icon = new ImageIcon(newImage);
        this.setIcon(icon);
    }
}
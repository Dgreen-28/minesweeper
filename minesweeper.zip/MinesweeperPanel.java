import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;


public class MinesweeperPanel extends JPanel {

    public MinesweeperButtons buttons;
    private MinesweeperModel model = new MinesweeperModel();
    private MinesweeperButtons arrButtons [][] = new MinesweeperButtons[15][15];
    private int row =0, collumn =0;

    private MinesweeperFrame frame;
    public int state =0;
    static ImageIcon flagged = new ImageIcon("flag.png");
    static ImageIcon opened = new ImageIcon("shape_square-512.png");
    static ImageIcon one = new ImageIcon("1.png");
    static ImageIcon two = new ImageIcon("2.png");
    static ImageIcon three = new ImageIcon("3.png");
    static ImageIcon four = new ImageIcon("4.png");
    static ImageIcon five = new ImageIcon("5.png");
    static ImageIcon six = new ImageIcon("6.png");
    static ImageIcon seven = new ImageIcon("7.png");
    static ImageIcon eight = new ImageIcon("8.png");
    static ImageIcon bomb = new ImageIcon("question.png");
    static ImageIcon question = new ImageIcon("mario question.png");

    public MinesweeperPanel(MinesweeperFrame frame){
        this.frame = frame;

        setLayout(new GridLayout(15, 15));
        for(int r =0;r <arrButtons.length;r++){
            for(int c =0;c <arrButtons.length;c++){
                arrButtons[r][c] = new MinesweeperButtons(frame, r, c);
                add(arrButtons[r][c]);

            }
         }
        }

        protected void paintComponent(Graphics g){
            //super.paintComponent(g);

            System.out.println(state);
            state = frame.model.getState(row, collumn);
            switch (state) {
                case MinesweeperModel.questioned: arrButtons[row][collumn].setImage(question, 28,28);
                    
                    break;
                case MinesweeperModel.flagged: arrButtons[row][collumn].setImage(flagged,28,28);

                    break;

                case 0: arrButtons[row][collumn].setImage(opened,28,28);

                break;
                case 1: arrButtons[row][collumn].setImage(one,28,28);

                    break;
                case 2: arrButtons[row][collumn].setImage(two,28,28);

                    break;
                case 3: arrButtons[row][collumn].setImage(three,28,28);

                    break;
                case 4: arrButtons[row][collumn].setImage(four,28,28);

                    break;
                case 5: arrButtons[row][collumn].setImage(five,28,28);

                    break;
                case 6: arrButtons[row][collumn].setImage(six,28,28);

                    break;
                case 7: arrButtons[row][collumn].setImage(seven,28,28);

                    break;
                case 8: arrButtons[row][collumn].setImage(eight,28,28);

                    break;
            

            }
            if(frame.model.checkMine(row,collumn) && frame.model.getState(row,collumn)!= MinesweeperModel.flagged){
                arrButtons[row][collumn].setImage(bomb,28,28);
            }

        } 
        public void updateFrame(int r , int c){
            row = r;
            collumn = c;
            System.out.println(r + " " + c);
            repaint();
        }

 }

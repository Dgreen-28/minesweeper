import javax.swing.*;

public class MinesweeperFrame extends JFrame {

        public MinesweeperModel model;
        MinesweeperPanel panel = new MinesweeperPanel(this);

    public MinesweeperFrame(MinesweeperModel model){
        this.model=model;
         setTitle("Minesweeper");
         setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         setSize(750,750);
         add(panel);
         setVisible(true);
     }
 }

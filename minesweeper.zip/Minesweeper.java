import javax.swing.JFrame;

public class Minesweeper {
    public static void main(String[] args) {
        MinesweeperModel m = new MinesweeperModel();
        MinesweeperFrame f = new MinesweeperFrame(m);
    }
}